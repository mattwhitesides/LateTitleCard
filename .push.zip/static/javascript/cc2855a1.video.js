// $(function() {

// 	var windowWidth = $(window).width();
// 	var video = document.getElementsByTagName("video")[0];
	
// 	var context = canvas.getContext("2d");

// 	console.log(video);

// 	video.width = windowWidth;
// 	video.height = (windowWidth * .5625);

// 	 context.font = 'bold 10pt Calibri';
//   context.fillText('Hello World!', 150, 100);
//   context.font = 'italic 40pt Times Roman';
//   context.fillStyle = 'blue';
//   context.fillText('Hello World!', 200, 150);
//   context.font = '60pt Calibri';
//   context.lineWidth = 4;
//   context.strokeStyle = 'blue';
//   context.strokeText('Hello World!', 70, 70);

// });